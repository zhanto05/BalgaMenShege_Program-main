package org.firstinspires.ftc.teamcode.driving;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055IMU.Parameters;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.ImuOrientationOnRobot;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;

@TeleOp(name = "MainXDrive")
public class Xdrive extends LinearOpMode {
    private DcMotor frontLeftMotor = null;
    private DcMotor backLeftMotor = null;
    private DcMotor frontRightMotor = null;
    private DcMotor backRightMotor = null;
    private IMU imu = null;

    @Override
    public void runOpMode(){
        frontLeftMotor = hardwareMap.get(DcMotor.class, "leftFront");
        backLeftMotor = hardwareMap.get(DcMotor.class, "leftRear");
        frontRightMotor = hardwareMap.get(DcMotor.class, "rightFront");
        backRightMotor = hardwareMap.get(DcMotor.class, "rightRear");

        frontLeftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backLeftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backRightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        imu = hardwareMap.get(IMU.class, "imu");
//// Adjust the orientation parameters to match your robot
//        BNO055IMU.Parameters parameters = new IMU.Parameters(new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.UP,
//                RevHubOrientationOnRobot.LogoFacingDirection.FORWARD));
//// Without this, the REV Hub's orientation is assumed to be logo up / USB forward
//        imu.initialize(parameters);

        frontLeftMotor.setDirection(DcMotor.Direction.REVERSE);
        backLeftMotor.setDirection(DcMotor.Direction.REVERSE);

//        waitForStart();
//        while(opModeIsActive()) {
//
//            double y = -gamepad1.left_stick_y; // Remember, this is reversed!
//            double x = gamepad1.left_stick_x;
//            double rx = gamepad1.right_stick_x;
//
//            frontLeftMotor.setPower(y + x + rx);
//            backLeftMotor.setPower(y - x + rx);
//            frontRightMotor.setPower(y - x - rx);
//            backRightMotor.setPower(y + x - rx);
//        }
        // Retrieve the IMU from the hardware map
        imu = hardwareMap.get(IMU.class, "imu");
        // Adjust the orientation parameters to match your robot
        IMU.Parameters parameters = new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.UP,
                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD));
        // Without this, the REV Hub's orientation is assumed to be logo up / USB forward
        imu.initialize(parameters);
        double savedHeading = 0.0;
        double targetHeading = 0.0;
        double turnRate = 0.25;
        double pHeading = 0.175;
        double errHeading = 0.0;

        if (isStopRequested()) return;
        waitForStart();
        while (opModeIsActive()) {
            double y = -gamepad1.left_stick_y; // Remember, this is reversed!
            double x = gamepad1.left_stick_x * 1.1; // Counteract imperfect strafing
            double rx = gamepad1.right_stick_x;

            if(y > 0.7){
                y = 1;
            }
            if(y<-0.7){
                y = -1;
            }
            if(x>0.7){
                x = 1;
            }
            if(x<-0.7){
                x = -1;
            }

            y *= 0.8; x *= 0.8;

            double absoluteHeading = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);

            double relativeHeading;
            if(gamepad1.b){
                savedHeading = absoluteHeading;
            }
            relativeHeading = absoluteHeading - savedHeading;
            if(Math.abs(rx) > 0.15){
                targetHeading = relativeHeading;
            }
            errHeading = targetHeading - relativeHeading;

            double rotVel = errHeading * pHeading;
            clamp(rotVel, 1);

            // Rotate the movement direction counter to the bot's rotation
            double rotX = x * Math.cos(-relativeHeading) - y * Math.sin(-relativeHeading);
            double rotY = x * Math.sin(-relativeHeading) + y * Math.cos(-relativeHeading);

//            double rotX = x * Math.cos(-relativeHeading);
//            double rotY = y * Math.cos(-relativeHeading);

            // Denominator is the largest motor power (absolute value) or 1
            // This ensures all the powers maintain the same ratio, but only when
            // at least one is out of the range [-1, 1]
            double denominator = Math.max(Math.abs(rotY) + Math.abs(rotX) + Math.abs(rx), 1);
            double frontLeftPower = (rotY + rotX + rx) / denominator;
            double backLeftPower = (rotY - rotX + rx) / denominator;
            double frontRightPower = (rotY - rotX - rx) / denominator;
            double backRightPower = (rotY + rotX - rx) / denominator;

            frontLeftMotor.setPower(frontLeftPower);
            backLeftMotor.setPower(backLeftPower);
            frontRightMotor.setPower(frontRightPower);
            backRightMotor.setPower(backRightPower);
            telemetry.addData("absolute heading", Math.toDegrees(absoluteHeading));
            telemetry.addData("saved heading", Math.toDegrees(savedHeading));
            telemetry.addData("relative heading", Math.toDegrees(relativeHeading));
            telemetry.addData("target heading", Math.toDegrees(targetHeading));
            telemetry.addData("error", Math.toDegrees(errHeading));
            telemetry.update();
        }
    }
    double clamp(double v, double bounds){
        return clamp(v, -bounds, bounds);
    }
    double clamp(double v, double min, double max){
        if(v > max){
            return max;
        }
        else if(v < min){
            return min;
        }
        else{
            return v;
        }
    }
}
